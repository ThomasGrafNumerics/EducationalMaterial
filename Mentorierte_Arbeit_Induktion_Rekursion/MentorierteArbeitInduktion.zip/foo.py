import numpy as np

def foo(n):
    # macht irgendwas
    for k in range(n):
        print('Schleife')